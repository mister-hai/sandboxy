__version__ = "0.0.9"
__name__ = "ctfcli"
